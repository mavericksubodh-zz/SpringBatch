package net.batch.batchloader.config;

public class Constants {

	/**
	 * Spring profile for running in "development mode"
	 */
	public static final String SPRING_PROFILE_DEVELOPMENT = "dev";

	/**
	 * Spring profile for running in "production mode"
	 */
	public static final String SPRING_PROFILE_PRODUCTION = "prod";


}
